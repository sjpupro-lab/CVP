/* test_cvp.c — Phase 4: CVP I/O + TimeMachine Replay */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>

#include "../include/canvasos_types.h"
#include "../include/canvasos_engine_ctx.h"
#include "../include/engine_time.h"
#include "../include/canvasos_gate_ops.h"
#include "../include/cvp_io.h"

static Cell      canvas_a[CANVAS_W * CANVAS_H];
static Cell      canvas_b[CANVAS_W * CANVAS_H];
static GateState gates_a[TILEGATE_COUNT];
static GateState gates_b[TILEGATE_COUNT];
static uint8_t   open_a[TILE_COUNT];
static uint8_t   open_b[TILE_COUNT];

#define TMP_PATH "/tmp/test_canvasos.cvp"

/* ---- helpers ---- */
static void ctx_init(EngineContext *ctx, Cell *cells,
                     GateState *gates, uint8_t *active) {
    memset(ctx, 0, sizeof(*ctx));
    ctx->cells       = cells;
    ctx->cells_count = CANVAS_W * CANVAS_H;
    ctx->gates       = gates;
    ctx->active_open = active;
}

/* =============================================
 * TEST 1: CRC32 self-consistency
 * ============================================= */
static void test_crc32(void) {
    printf("\n=== TEST 1: CRC32 ===\n");
    const char *s = "CanvasOS CVP";
    uint32_t c1 = cvp_crc32(s, (uint32_t)strlen(s));
    uint32_t c2 = cvp_crc32(s, (uint32_t)strlen(s));
    assert(c1 == c2);
    assert(c1 != 0 && c1 != 0xFFFFFFFFu);
    /* known-good: empty string */
    uint32_t ce = cvp_crc32("", 0);
    assert(ce == 0x00000000u);   /* CRC32("") = 0 */
    printf("CRC32 '%s' = 0x%08X\n", s, c1);
    printf("[PASS] TEST 1\n");
}

/* =============================================
 * TEST 2: save / validate / load round-trip
 * ============================================= */
static void test_save_load(void) {
    printf("\n=== TEST 2: save/validate/load round-trip ===\n");

    EngineContext ctx_w, ctx_r;
    ctx_init(&ctx_w, canvas_a, gates_a, open_a);
    ctx_init(&ctx_r, canvas_b, gates_b, open_b);
    memset(canvas_a, 0, sizeof(canvas_a));
    memset(canvas_b, 0, sizeof(canvas_b));
    memset(gates_a,  0, sizeof(gates_a));
    memset(gates_b,  0, sizeof(gates_b));

    /* write known pattern into canvas_a */
    for (uint32_t i = 0; i < 256; i++) {
        canvas_a[i].A   = 0xDEAD0000u | i;
        canvas_a[i].B   = (uint8_t)(i & 0xFF);
        canvas_a[i].G   = (uint8_t)((i * 3) & 0xFF);
        canvas_a[i].R   = (uint8_t)((i * 7) & 0xFF);
        canvas_a[i].pad = 0;
    }
    /* open some gates */
    gate_open_tile(&ctx_w, 100);
    gate_open_tile(&ctx_w, 200);
    gate_open_tile(&ctx_w, 500);

    /* save */
    CvpSaveOpts opts = { .include_gates = true, .include_wh = false, .include_bh = false };
    CvpResult r = cvp_save(TMP_PATH, &ctx_w, &opts);
    printf("save: %s\n", cvp_strerror(r));
    assert(r == CVP_OK);

    /* validate */
    r = cvp_validate(TMP_PATH);
    printf("validate: %s\n", cvp_strerror(r));
    assert(r == CVP_OK);

    /* load into ctx_r */
    r = cvp_load(TMP_PATH, &ctx_r);
    printf("load: %s\n", cvp_strerror(r));
    assert(r == CVP_OK);

    /* verify canvas data */
    for (uint32_t i = 0; i < 256; i++) {
        assert(canvas_b[i].A == canvas_a[i].A);
        assert(canvas_b[i].B == canvas_a[i].B);
        assert(canvas_b[i].G == canvas_a[i].G);
        assert(canvas_b[i].R == canvas_a[i].R);
    }
    printf("canvas data round-trip: 256 cells OK\n");

    /* verify gate bitmap */
    assert(gate_is_open_tile(&ctx_r, 100) == 1);
    assert(gate_is_open_tile(&ctx_r, 200) == 1);
    assert(gate_is_open_tile(&ctx_r, 500) == 1);
    assert(gate_is_open_tile(&ctx_r, 99)  == 0);
    printf("gate bitmap round-trip: OK\n");
    printf("[PASS] TEST 2\n");
}

/* =============================================
 * TEST 3: corrupt file → CVP_ERR_MAGIC / CVP_ERR_CRC
 * ============================================= */
static void test_corrupt(void) {
    printf("\n=== TEST 3: corruption detection ===\n");

    /* bad magic */
    FILE *fp = fopen(TMP_PATH, "r+b");
    assert(fp);
    fwrite("XXXX", 1, 4, fp);
    fclose(fp);
    assert(cvp_validate(TMP_PATH) == CVP_ERR_MAGIC);
    printf("bad magic: CVP_ERR_MAGIC OK\n");

    /* restore file then corrupt CRC byte */
    EngineContext ctx_w;
    ctx_init(&ctx_w, canvas_a, gates_a, open_a);
    CvpSaveOpts opts = {0};
    assert(cvp_save(TMP_PATH, &ctx_w, &opts) == CVP_OK);

    fp = fopen(TMP_PATH, "r+b");
    assert(fp);
    fseek(fp, 32, SEEK_SET);   /* header_crc32 offset */
    uint8_t bad = 0xAA;
    fwrite(&bad, 1, 1, fp);
    fclose(fp);
    assert(cvp_validate(TMP_PATH) == CVP_ERR_CRC);
    printf("bad CRC: CVP_ERR_CRC OK\n");
    printf("[PASS] TEST 3\n");
}

/* =============================================
 * TEST 4: WH save + replay
 * ============================================= */
static void test_wh_replay(void) {
    printf("\n=== TEST 4: WH lane save + replay ===\n");

    EngineContext ctx_w, ctx_r;
    ctx_init(&ctx_w, canvas_a, gates_a, open_a);
    ctx_init(&ctx_r, canvas_b, gates_b, open_b);
    memset(canvas_a, 0, sizeof(canvas_a));
    memset(canvas_b, 0, sizeof(canvas_b));
    memset(gates_a,  0, sizeof(gates_a));
    memset(gates_b,  0, sizeof(gates_b));

    /* write WH records: open gate 77 at tick 0, 1, 2 */
    for (uint64_t t = 0; t < 3; t++) {
        WhRecord r = {0};
        r.tick_or_event = (uint32_t)t;
        r.opcode_index  = (t < 2) ? WH_OP_GATE_OPEN : WH_OP_GATE_CLOSE;
        r.target_kind   = WH_TGT_TILE;
        r.target_addr   = 77;
        wh_write_record(&ctx_w, t, &r);
    }

    CvpSaveOpts opts = { .include_wh = true, .include_gates = true, .include_bh = false };
    assert(cvp_save(TMP_PATH, &ctx_w, &opts) == CVP_OK);
    printf("saved with WH lane\n");

    /* replay tick 0..1 only (gate open records) into ctx_r */
    CvpReplayOpts ropts = { .tick_from = 0, .tick_to = 1, .dry_run = false };
    CvpResult r = cvp_replay(TMP_PATH, &ctx_r, &ropts);
    printf("replay tick 0..1: %s\n", cvp_strerror(r));
    assert(r == CVP_OK);
    /* gate 77 should be open (tick 0 = OPEN, tick 1 = OPEN) */
    assert(gate_is_open_tile(&ctx_r, 77) == 1);
    printf("gate 77 open after replay OK\n");

    /* dry run — no side effects */
    gate_close_tile(&ctx_r, 77);
    CvpReplayOpts dry = { .tick_from = 0, .tick_to = 2, .dry_run = true };
    assert(cvp_replay(TMP_PATH, &ctx_r, &dry) == CVP_OK);
    assert(gate_is_open_tile(&ctx_r, 77) == 0);   /* unchanged: dry run */
    printf("dry_run: gate unchanged OK\n");
    printf("[PASS] TEST 4\n");
}

/* =============================================
 * TEST 5: BH state save/load
 * ============================================= */
static void test_bh_roundtrip(void) {
    printf("\n=== TEST 5: BH state round-trip ===\n");

    EngineContext ctx_w, ctx_r;
    ctx_init(&ctx_w, canvas_a, gates_a, open_a);
    ctx_init(&ctx_r, canvas_b, gates_b, open_b);
    memset(canvas_a, 0, sizeof(canvas_a));
    memset(canvas_b, 0, sizeof(canvas_b));

    /* set energy for pid 0, 1, 2 */
    bh_set_energy(&ctx_w, 0, 100, 200);
    bh_set_energy(&ctx_w, 1, 50,  200);
    bh_set_energy(&ctx_w, 2, 0,   200);

    CvpSaveOpts opts = { .include_bh = true };
    assert(cvp_save(TMP_PATH, &ctx_w, &opts) == CVP_OK);
    assert(cvp_load(TMP_PATH, &ctx_r) == CVP_OK);

    assert(bh_get_energy(&ctx_r, 0) == 100);
    assert(bh_get_energy(&ctx_r, 1) == 50);
    assert(bh_get_energy(&ctx_r, 2) == 0);
    printf("pid0 energy=%u pid1 energy=%u pid2 energy=%u\n",
           bh_get_energy(&ctx_r, 0),
           bh_get_energy(&ctx_r, 1),
           bh_get_energy(&ctx_r, 2));
    printf("[PASS] TEST 5\n");
}

/* =============================================
 * TEST 6: determinism — same CVP, same canvas hash
 * ============================================= */
static void test_determinism(void) {
    printf("\n=== TEST 6: determinism (same CVP → same canvas) ===\n");

    EngineContext ctx_1, ctx_2;
    static Cell c1[CANVAS_W * CANVAS_H];
    static Cell c2[CANVAS_W * CANVAS_H];
    static GateState g1[TILEGATE_COUNT], g2[TILEGATE_COUNT];
    ctx_init(&ctx_1, c1, g1, NULL);
    ctx_init(&ctx_2, c2, g2, NULL);

    /* fill canvas with deterministic data */
    for (uint32_t i = 0; i < CANVAS_W * CANVAS_H; i++) {
        c1[i].A = i * 0x1234ABCDu;
        c1[i].B = (uint8_t)(i);
        c1[i].G = (uint8_t)(i >> 8);
        c1[i].R = (uint8_t)(i >> 16);
    }
    CvpSaveOpts opts = {0};
    assert(cvp_save(TMP_PATH, &ctx_1, &opts) == CVP_OK);

    assert(cvp_load(TMP_PATH, &ctx_1) == CVP_OK);
    assert(cvp_load(TMP_PATH, &ctx_2) == CVP_OK);

    /* CRC32 of both canvases must match */
    uint32_t h1 = cvp_crc32(c1, sizeof(c1));
    uint32_t h2 = cvp_crc32(c2, sizeof(c2));
    printf("canvas hash A=0x%08X B=0x%08X\n", h1, h2);
    assert(h1 == h2);
    printf("[PASS] TEST 6\n");
}

int main(void) {
    printf("=== Phase 4: CVP I/O Tests ===\n");
    test_crc32();
    test_save_load();
    test_corrupt();
    test_wh_replay();
    test_bh_roundtrip();
    test_determinism();
    printf("\n=== ALL CVP TESTS PASSED ===\n");
    return 0;
}
