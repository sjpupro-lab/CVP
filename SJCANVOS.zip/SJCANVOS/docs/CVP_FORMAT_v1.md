# CVP Format v1 — CanvasOS Canvas Package

> Phase 4 구현 스펙. 단일 .cvp 파일로 부팅/저장/복원 완결.

## 핵심 원칙

- Canvas(.cvp) 하나로 OS 상태 완결
- 데이터 이동 없음 — BpageChain/RuleTable 교체로 해석 레이어만 변경
- WH 레코드가 유일한 리플레이 소스 (별도 저널 없음)
- Always-ON: 기본 상태 CLOSE, OPEN 신호만 흐름

## 파일 레이아웃

    offset 0       : CvpFileHeader (4096 bytes)
    offset 4096    : Section TLV stream
      [ CvpSectionHdr | payload ]*

## CvpFileHeader (고정 4096 bytes)

    magic[4]         "CVP1"
    version          u32   0x00010000 = v1.0
    endian_check     u32   0x12345678
    canvas_w         u32   1024
    canvas_h         u32   1024
    section_count    u32   sections 수
    reserved_lo      u32   FS_RESERVED_LO gate_id  (2080)
    reserved_hi      u32   FS_RESERVED_HI gate_id  (2275)
    header_crc32     u32   헤더 자신의 CRC32 (이 필드 제외)
    [padding]        bytes → offset 4096까지 0x00

## Section TLV

    CvpSectionHdr {
      type    u32   SectionType enum
      flags   u32   bit0=optional, bit1..=reserved
      length  u32   payload bytes (헤더 미포함)
      crc32   u32   payload CRC32
    }
    payload[length]

## SectionType

    CVP_SEC_CANVAS_BASE = 1   필수. Cell 배열 raw dump
    CVP_SEC_GATE_BITMAP = 2   선택. 게이트 open/close 비트맵
    CVP_SEC_WH_LANE     = 3   선택. WhRecord 스트림
    CVP_SEC_BH_STATE    = 4   선택. pid energy state (BH)
    CVP_SEC_RULETABLE   = 5   선택. RuleTable dump

## CANVAS_BASE 페이로드

    Cell[CANVAS_W * CANVAS_H]
    Cell = { A:u32LE, B:u8, G:u8, R:u8, pad:u8 } = 8 bytes
    총 1024 × 1024 × 8 = 8,388,608 bytes

## GATE_BITMAP 페이로드

    uint8_t bitmap[512]   — 4096 bits, gate_id i → byte[i/8] bit(i%8)
    OPEN=1 CLOSE=0, LSB first

## WH_LANE 페이로드

    uint64_t tick_first     — 기록된 첫 번째 tick
    uint64_t tick_last      — 기록된 마지막 tick
    WhRecord records[]      — 순서 있는 2-cell 레코드 배열
    (각 WhRecord = 16 bytes: C0 8B + C1 8B)

## CRC32

    다항식 0xEDB88320 (ISO 3309, zlib 호환)
    초기값  0xFFFFFFFF
    최종    ^= 0xFFFFFFFF

## 오류 코드

    CVP_OK           =  0
    CVP_ERR_IO       = -1   파일 열기/읽기/쓰기 실패
    CVP_ERR_MAGIC    = -2   magic 불일치
    CVP_ERR_VERSION  = -3   버전 미지원
    CVP_ERR_CRC      = -4   CRC 불일치
    CVP_ERR_SIZE     = -5   canvas 크기 불일치
    CVP_ERR_OOM      = -6   메모리 부족
    CVP_ERR_SECTION  = -7   필수 section 없음
