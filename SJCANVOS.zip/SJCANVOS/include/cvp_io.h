#pragma once
#include <stdint.h>
#include <stdbool.h>
#include "canvasos_types.h"
#include "canvasos_engine_ctx.h"
#include "engine_time.h"

/* =====================================================
 * CVP I/O — Phase 4
 * Single-file canvas package: save / load / validate / replay
 * ===================================================== */

/* ---- section types ---- */
typedef enum {
    CVP_SEC_CANVAS_BASE = 1,
    CVP_SEC_GATE_BITMAP = 2,
    CVP_SEC_WH_LANE     = 3,
    CVP_SEC_BH_STATE    = 4,
    CVP_SEC_RULETABLE   = 5,
} CvpSectionType;

/* ---- section flags ---- */
#define CVP_FLAG_OPTIONAL  0x01u

/* ---- error codes ---- */
typedef enum {
    CVP_OK          =  0,
    CVP_ERR_IO      = -1,
    CVP_ERR_MAGIC   = -2,
    CVP_ERR_VERSION = -3,
    CVP_ERR_CRC     = -4,
    CVP_ERR_SIZE    = -5,
    CVP_ERR_OOM     = -6,
    CVP_ERR_SECTION = -7,
} CvpResult;

/* ---- file header (fixed 4096 bytes) ---- */
#define CVP_HEADER_SIZE  4096u
#define CVP_VERSION      0x00010000u
#define CVP_ENDIAN_CHECK 0x12345678u

typedef struct __attribute__((packed)) {
    uint8_t  magic[4];         /* "CVP1"          */
    uint32_t version;          /* 0x00010000      */
    uint32_t endian_check;     /* 0x12345678      */
    uint32_t canvas_w;
    uint32_t canvas_h;
    uint32_t section_count;
    uint32_t reserved_lo;      /* FS_RESERVED_LO  */
    uint32_t reserved_hi;      /* FS_RESERVED_HI  */
    uint32_t header_crc32;     /* CRC of bytes 0..(this_field-1) */
} CvpFileHeader;

/* ---- section header ---- */
typedef struct __attribute__((packed)) {
    uint32_t type;
    uint32_t flags;
    uint32_t length;    /* payload bytes */
    uint32_t crc32;     /* payload CRC32 */
} CvpSectionHdr;

/* ---- WH lane section payload header ---- */
typedef struct __attribute__((packed)) {
    uint64_t tick_first;
    uint64_t tick_last;
    uint32_t record_count;
    uint32_t pad;
} CvpWhLaneHdr;

/* ---- WhRecord on-disk (16 bytes) ---- */
typedef struct __attribute__((packed)) {
    uint32_t tick_or_event;
    uint8_t  opcode_index;
    uint8_t  flags;
    uint8_t  param0;
    uint8_t  _pad0;
    uint32_t target_addr;
    uint8_t  target_kind;
    uint8_t  arg_state;
    uint8_t  param1;
    uint8_t  _pad1;
} CvpWhRecord;

/* ---- save options ---- */
typedef struct {
    bool include_wh;       /* capture WH lane in file  */
    bool include_bh;       /* capture BH state         */
    bool include_gates;    /* capture gate bitmap       */
} CvpSaveOpts;

/* ---- replay context ---- */
typedef struct {
    uint64_t tick_from;
    uint64_t tick_to;
    bool     dry_run;      /* verify only, no side effects */
} CvpReplayOpts;

/* =====================================================
 * API
 * ===================================================== */

/* CRC32 (ISO 3309, poly 0xEDB88320) */
uint32_t cvp_crc32(const void *data, uint32_t len);

/* Save: ctx → .cvp file */
CvpResult cvp_save(const char *path, EngineContext *ctx,
                   const CvpSaveOpts *opts);

/* Load: .cvp file → ctx (canvas + optional gates/WH/BH) */
CvpResult cvp_load(const char *path, EngineContext *ctx);

/* Validate: check magic / version / CRC only (no ctx needed) */
CvpResult cvp_validate(const char *path);

/* Replay: re-execute WH records from file into ctx */
CvpResult cvp_replay(const char *path, EngineContext *ctx,
                     const CvpReplayOpts *opts);

/* Human-readable result string */
const char *cvp_strerror(CvpResult r);
