#pragma once
#include <stdint.h>

/* Opcode classes */
typedef enum {
    OP_NONE   = 0,
    OP_GATE   = 1,
    OP_TIME   = 2,
    OP_FS     = 3,
    OP_COMMIT = 4,
    OP_CVP    = 5,   /* Phase 4: CVP I/O */
    OP_RULE   = 6,   /* Phase 4: RuleTable */
} OpClass;

/* Opcode codes (stable, from SSOT) */
typedef enum {
#define X(NAME, CODE, CLASS, TAGS, KEYWORDS, DESC) OP_##NAME = (CODE),
#include "canvasos_opcodes.def"
#undef X
} OpcodeCode;

const char* opcode_name(uint8_t code);
const char* opcode_desc(uint8_t code);
OpClass     opcode_class(uint8_t code);
const char* opcode_tags(uint8_t code);
const char* opcode_keywords(uint8_t code);
