#include "canvasos_opcodes.h"

typedef struct {
  uint8_t code;
  OpClass cls;
  const char* name;
  const char* tags;
  const char* keywords;
  const char* desc;
} OpcodeInfo;

static const OpcodeInfo kOpcodes[] = {
#define X(NAME, CODE, CLASS, TAGS, KEYWORDS, DESC) { (uint8_t)(CODE), (CLASS), #NAME, (TAGS), (KEYWORDS), (DESC) },
#include "canvasos_opcodes.def"
#undef X
};

static const OpcodeInfo* find(uint8_t code) {
  for (unsigned i=0;i<sizeof(kOpcodes)/sizeof(kOpcodes[0]);i++){
    if (kOpcodes[i].code == code) return &kOpcodes[i];
  }
  return 0;
}

const char* opcode_name(uint8_t code) { const OpcodeInfo* p=find(code); return p? p->name : "UNKNOWN"; }
const char* opcode_desc(uint8_t code) { const OpcodeInfo* p=find(code); return p? p->desc : "Unknown opcode"; }
OpClass opcode_class(uint8_t code) { const OpcodeInfo* p=find(code); return p? p->cls : OP_NONE; }
const char* opcode_tags(uint8_t code) { const OpcodeInfo* p=find(code); return p? p->tags : ""; }
const char* opcode_keywords(uint8_t code) { const OpcodeInfo* p=find(code); return p? p->keywords : ""; }
