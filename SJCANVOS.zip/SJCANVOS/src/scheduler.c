#include "../include/canvasos_sched.h"
#include "../include/engine_time.h"
#include "../include/canvasos_gate_ops.h"
#include <string.h>
#include <stdio.h>

/* =====================================================
 * Phase 3 Scheduler — 구현 (Always-ON + Gate Filtering)
 * ===================================================== */

static void gate_open_space_local(ActiveSet *as, GateSpace sp) {
    if (!as) return;
    if (sp.volh < TILE_COUNT) as->open[sp.volh] = 1;
    if (sp.volt < TILE_COUNT) as->open[sp.volt] = 1;
}
static void gate_close_space_local(ActiveSet *as, GateSpace sp) {
    if (!as) return;
    if (sp.volh < TILE_COUNT) as->open[sp.volh] = 0;
    if (sp.volt < TILE_COUNT) as->open[sp.volt] = 0;
}
static void gate_open_space_sched(Scheduler *sc, GateSpace sp) {
    if (sc && sc->ctx) gate_open_space_ctx(sc->ctx, sp);
    else gate_open_space_local(sc ? sc->aset : NULL, sp);
}
static void gate_close_space_sched(Scheduler *sc, GateSpace sp) {
    if (sc && sc->ctx) gate_close_space_ctx(sc->ctx, sp);
    else gate_close_space_local(sc ? sc->aset : NULL, sp);
}


void sched_init(Scheduler *sc, ActiveSet *aset) {
    memset(sc, 0, sizeof(*sc));
    sc->aset     = aset;
    sc->next_pid = 1;
}

void sched_bind_ctx(Scheduler *sc, EngineContext *ctx) {
    if (!sc) return;
    sc->ctx = ctx;
    /* Mirror ActiveSet bitmap into ctx fast path if available */
    if (sc->ctx && sc->aset) sc->ctx->active_open = sc->aset->open;
}

int sched_spawn(Scheduler *sc, GateSpace space,
                uint32_t energy, uint32_t energy_max) {
    if (sc->count >= PROC_MAX) return -1;
    Process *p = &sc->procs[sc->count++];
    memset(p, 0, sizeof(*p));
    p->pid          = sc->next_pid++;
    p->state        = PROC_RUNNING;
    p->space        = space;
    p->energy       = energy;
    p->energy_max   = energy_max ? energy_max : energy;
    p->tick_born    = sc->tick;
    p->tick_last    = sc->tick;

    /* Formal ctx: initialize BH energy state */
    if (sc->ctx) {
        uint8_t e = (energy > 255u) ? 255u : (uint8_t)energy;
        uint8_t m = (energy_max > 255u) ? 255u : (uint8_t)energy_max;
        bh_set_energy(sc->ctx, (uint16_t)p->pid, e, m);
        /* WH record: spawn heartbeat */
        WhRecord wr = {0};
        wr.tick_or_event = sc->tick;
        wr.opcode_index  = WH_OP_TICK;
        wr.flags         = 0;
        wr.param0        = 0;
        wr.target_addr   = (uint32_t)p->pid;
        wr.target_kind   = WH_TGT_PROC;
        wr.arg_state     = (uint8_t)p->state;
        wr.param1        = 0;
        wh_write_record(sc->ctx, ((uint64_t)sc->tick<<8) | (uint64_t)(p->pid & 0xFFu), &wr);
    }
    p->cvp_section  = 0;
    p->mount_canvas = 0xFFFF;
    /* open gate space on spawn */
    gate_open_space_sched(sc, space);
    return (int)p->pid;
}

int sched_tick(Scheduler *sc) {
    sc->tick++;
    int ran = 0;
    for (uint32_t i = 0; i < sc->count; i++) {
        Process *p = &sc->procs[i];
        if (p->state != PROC_RUNNING) continue;
        ran++;
        p->tick_last = sc->tick;
        if (p->energy > 0) {
            p->energy--;
        }
        if (p->energy == 0) {
            p->state = PROC_SLEEPING;
        if (sc->ctx) {
            WhRecord wr = {0};
            wr.tick_or_event = sc->tick;
            wr.opcode_index  = WH_OP_SLEEP;
            wr.flags         = 0;
            wr.param0        = 0;
            wr.target_addr   = (uint32_t)p->pid;
            wr.target_kind   = WH_TGT_PROC;
            wr.arg_state     = (uint8_t)p->state;
            wr.param1        = 0;
            wh_write_record(sc->ctx, ((uint64_t)sc->tick<<8) | (uint64_t)(p->pid & 0xFFu), &wr);
        }
            gate_close_space_sched(sc, p->space);
        }
    }
    return ran;
}

void sched_recharge(Scheduler *sc, uint32_t pid, uint32_t amount) {
    for (uint32_t i = 0; i < sc->count; i++) {
        Process *p = &sc->procs[i];
        if (p->pid != pid) continue;
        p->energy += amount;
    if (sc->ctx) {
        uint8_t e = (p->energy > 255u) ? 255u : (uint8_t)p->energy;
        uint8_t m = (p->energy_max > 255u) ? 255u : (uint8_t)p->energy_max;
        bh_set_energy(sc->ctx, (uint16_t)p->pid, e, m);
    }
        if (p->energy > p->energy_max) p->energy = p->energy_max;
        if (p->state == PROC_SLEEPING && p->energy > 0) {
            p->state = PROC_RUNNING;
            gate_open_space_sched(sc, p->space);
        if (sc->ctx) {
            WhRecord wr = {0};
            wr.tick_or_event = sc->tick;
            wr.opcode_index  = WH_OP_WAKE;
            wr.flags         = 0;
            wr.param0        = 0;
            wr.target_addr   = (uint32_t)p->pid;
            wr.target_kind   = WH_TGT_PROC;
            wr.arg_state     = (uint8_t)p->state;
            wr.param1        = 0;
            wh_write_record(sc->ctx, ((uint64_t)sc->tick<<8) | (uint64_t)(p->pid & 0xFFu), &wr);
        }
        }
        return;
    }
}

void sched_kill(Scheduler *sc, uint32_t pid) {
    for (uint32_t i = 0; i < sc->count; i++) {
        Process *p = &sc->procs[i];
        if (p->pid != pid) continue;
        p->state  = PROC_ZOMBIE;
        p->energy = 0;
        gate_close_space_sched(sc, p->space);
        return;
    }
}

int sched_owner(const Scheduler *sc, uint16_t x, uint16_t y) {
    /* VOLT tile의 x0..x0+15, y0..y0+15 범위를 체크 */
    for (uint32_t i = 0; i < sc->count; i++) {
        const Process *p = &sc->procs[i];
        if (p->state == PROC_ZOMBIE) continue;
        uint16_t volt = p->space.volt;
        uint16_t vx0  = (uint16_t)((volt % TILES_X) * TILE);
        uint16_t vy0  = (uint16_t)((volt / TILES_X) * TILE);
        if (x >= vx0 && x < (uint16_t)(vx0 + TILE) &&
            y >= vy0 && y < (uint16_t)(vy0 + TILE)) {
            return (int)p->pid;
        }
    }
    return -1;
}

void sched_dump(const Scheduler *sc) {
    static const char *snames[] = {"RUNNING","SLEEPING","BLOCKED","ZOMBIE"};
    printf("=== Scheduler tick=%u procs=%u ===\n", sc->tick, sc->count);
    for (uint32_t i = 0; i < sc->count; i++) {
        const Process *p = &sc->procs[i];
        printf("  pid=%u %-8s energy=%u/%u volh=%u volt=%u cvp=%u mount=%u\n",
               p->pid, snames[p->state & 3],
               p->energy, p->energy_max,
               p->space.volh, p->space.volt,
               p->cvp_section, p->mount_canvas);
    }
}

/* ---- Phase 4/5 stubs ---- */
void sched_set_cvp(Scheduler *sc, uint32_t pid, uint32_t cvp_section) {
    for (uint32_t i = 0; i < sc->count; i++) {
        if (sc->procs[i].pid == pid) {
            sc->procs[i].cvp_section = cvp_section;
            return;
        }
    }
}

/* Phase 5: IPC — 스텁, Phase 5 구현에서 교체 */
int sched_ipc_send(Scheduler *sc, const IpcMsg *msg) {
    (void)sc; (void)msg;
    return -1; /* Phase 5 미구현 */
}
int sched_ipc_recv(Scheduler *sc, uint32_t pid, IpcMsg *out) {
    (void)sc; (void)pid; (void)out;
    return -1; /* Phase 5 미구현 */
}
