#include "../include/cvp_io.h"
#include "../include/canvasfs.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* =====================================================
 * CVP I/O — Phase 4 실제 구현
 * ===================================================== */

/* ---- CRC32 (ISO 3309 / zlib) ---- */
static uint32_t crc32_table[256];
static int      crc32_ready = 0;

static void crc32_init(void) {
    if (crc32_ready) return;
    for (uint32_t i = 0; i < 256; i++) {
        uint32_t c = i;
        for (int k = 0; k < 8; k++)
            c = (c & 1) ? (0xEDB88320u ^ (c >> 1)) : (c >> 1);
        crc32_table[i] = c;
    }
    crc32_ready = 1;
}

uint32_t cvp_crc32(const void *data, uint32_t len) {
    crc32_init();
    uint32_t crc = 0xFFFFFFFFu;
    const uint8_t *p = (const uint8_t *)data;
    for (uint32_t i = 0; i < len; i++)
        crc = crc32_table[(crc ^ p[i]) & 0xFF] ^ (crc >> 8);
    return crc ^ 0xFFFFFFFFu;
}

const char *cvp_strerror(CvpResult r) {
    switch (r) {
        case CVP_OK:          return "OK";
        case CVP_ERR_IO:      return "I/O error";
        case CVP_ERR_MAGIC:   return "bad magic";
        case CVP_ERR_VERSION: return "unsupported version";
        case CVP_ERR_CRC:     return "CRC mismatch";
        case CVP_ERR_SIZE:    return "canvas size mismatch";
        case CVP_ERR_OOM:     return "out of memory";
        case CVP_ERR_SECTION: return "missing required section";
        default:              return "unknown error";
    }
}

/* ---- helpers ---- */
static int write_u32le(FILE *fp, uint32_t v) {
    uint8_t b[4] = { (uint8_t)v, (uint8_t)(v>>8),
                     (uint8_t)(v>>16), (uint8_t)(v>>24) };
    return fwrite(b, 1, 4, fp) == 4 ? 0 : -1;
}
static int read_u32le(FILE *fp, uint32_t *out) {
    uint8_t b[4];
    if (fread(b, 1, 4, fp) != 4) return -1;
    *out = (uint32_t)b[0] | ((uint32_t)b[1]<<8) |
           ((uint32_t)b[2]<<16) | ((uint32_t)b[3]<<24);
    return 0;
}


/* =====================================================
 * SAVE
 * ===================================================== */

/* write a complete section: header + payload */
static CvpResult write_section(FILE *fp, uint32_t type, uint32_t flags,
                                const void *payload, uint32_t len) {
    uint32_t crc = cvp_crc32(payload, len);
    if (write_u32le(fp, type)  < 0) return CVP_ERR_IO;
    if (write_u32le(fp, flags) < 0) return CVP_ERR_IO;
    if (write_u32le(fp, len)   < 0) return CVP_ERR_IO;
    if (write_u32le(fp, crc)   < 0) return CVP_ERR_IO;
    if (len > 0 && fwrite(payload, 1, len, fp) != len) return CVP_ERR_IO;
    return CVP_OK;
}

CvpResult cvp_save(const char *path, EngineContext *ctx,
                   const CvpSaveOpts *opts) {
    if (!path || !ctx || !ctx->cells) return CVP_ERR_IO;

    FILE *fp = fopen(path, "wb");
    if (!fp) return CVP_ERR_IO;

    /* ---- header placeholder ---- */
    uint8_t hdr_buf[CVP_HEADER_SIZE];
    memset(hdr_buf, 0, sizeof(hdr_buf));
    /* write placeholder now, come back to fill CRC */
    if (fwrite(hdr_buf, 1, CVP_HEADER_SIZE, fp) != CVP_HEADER_SIZE) {
        fclose(fp); return CVP_ERR_IO;
    }

    uint32_t section_count = 0;
    CvpResult rc;

    /* ---- CANVAS_BASE (필수) ---- */
    uint32_t cell_count = (uint32_t)CANVAS_W * (uint32_t)CANVAS_H;
    uint32_t canvas_bytes = cell_count * 8u;  /* Cell = 8 bytes */
    uint8_t *raw = (uint8_t *)malloc(canvas_bytes);
    if (!raw) { fclose(fp); return CVP_ERR_OOM; }

    /* serialize each cell: A(4B LE) B G R pad */
    for (uint32_t i = 0; i < cell_count; i++) {
        const Cell *c = &ctx->cells[i];
        uint8_t *d = raw + i * 8;
        d[0] = (uint8_t)(c->A);      d[1] = (uint8_t)(c->A>>8);
        d[2] = (uint8_t)(c->A>>16);  d[3] = (uint8_t)(c->A>>24);
        d[4] = c->B; d[5] = c->G; d[6] = c->R; d[7] = c->pad;
    }
    rc = write_section(fp, CVP_SEC_CANVAS_BASE, 0, raw, canvas_bytes);
    free(raw);
    if (rc != CVP_OK) { fclose(fp); return rc; }
    section_count++;

    /* ---- GATE_BITMAP (선택) ---- */
    bool do_gates = opts ? opts->include_gates : true;
    if (do_gates && ctx->gates) {
        uint8_t bitmap[512]; memset(bitmap, 0, sizeof(bitmap));
        for (uint32_t g = 0; g < TILE_COUNT; g++)
            if (ctx->gates[g] == GATE_OPEN)
                bitmap[g/8] |= (uint8_t)(1u << (g%8));
        rc = write_section(fp, CVP_SEC_GATE_BITMAP, CVP_FLAG_OPTIONAL,
                            bitmap, sizeof(bitmap));
        if (rc != CVP_OK) { fclose(fp); return rc; }
        section_count++;
    }

    /* ---- WH_LANE (선택) ---- */
    bool do_wh = opts ? opts->include_wh : false;
    if (do_wh) {
        /* scan WH region and collect non-NOP records */
        uint64_t tick_first = 0, tick_last = 0;
        uint32_t rec_count = 0;
        /* count first pass */
        for (uint64_t t = 0; t < WH_CAP; t++) {
            WhRecord r; wh_read_record(ctx, t, &r);
            if (r.opcode_index != 0) {
                if (rec_count == 0) tick_first = t;
                tick_last = t;
                rec_count++;
            }
        }
        if (rec_count > 0) {
            uint32_t wh_hdr_bytes  = 20u;  /* CvpWhLaneHdr */
            uint32_t wh_rec_bytes  = rec_count * 16u;
            uint32_t wh_total = wh_hdr_bytes + wh_rec_bytes;
            uint8_t *wh_buf = (uint8_t *)malloc(wh_total);
            if (!wh_buf) { fclose(fp); return CVP_ERR_OOM; }

            /* write CvpWhLaneHdr */
            uint8_t *p = wh_buf;
            /* tick_first u64 LE */
            for (int i=0;i<8;i++) *p++ = (uint8_t)(tick_first>>(8*i));
            for (int i=0;i<8;i++) *p++ = (uint8_t)(tick_last>>(8*i));
            *p++ = (uint8_t)rec_count;       *p++ = (uint8_t)(rec_count>>8);
            *p++ = (uint8_t)(rec_count>>16); *p++ = (uint8_t)(rec_count>>24);

            /* second pass: write records */
            for (uint64_t t = 0; t < WH_CAP; t++) {
                WhRecord r; wh_read_record(ctx, t, &r);
                if (r.opcode_index == 0) continue;
                /* tick_or_event u32 LE */
                *p++ = (uint8_t)(r.tick_or_event);
                *p++ = (uint8_t)(r.tick_or_event>>8);
                *p++ = (uint8_t)(r.tick_or_event>>16);
                *p++ = (uint8_t)(r.tick_or_event>>24);
                *p++ = r.opcode_index; *p++ = r.flags;
                *p++ = r.param0;       *p++ = 0;
                *p++ = (uint8_t)(r.target_addr);
                *p++ = (uint8_t)(r.target_addr>>8);
                *p++ = (uint8_t)(r.target_addr>>16);
                *p++ = (uint8_t)(r.target_addr>>24);
                *p++ = r.target_kind; *p++ = r.arg_state;
                *p++ = r.param1;      *p++ = 0;
            }
            rc = write_section(fp, CVP_SEC_WH_LANE, CVP_FLAG_OPTIONAL,
                                wh_buf, wh_total);
            free(wh_buf);
            if (rc != CVP_OK) { fclose(fp); return rc; }
            section_count++;
        }
    }

    /* ---- BH_STATE (선택) — dump BH region raw ---- */
    bool do_bh = opts ? opts->include_bh : false;
    if (do_bh) {
        uint32_t bh_cells = (uint32_t)BH_W * (uint32_t)BH_H;
        uint32_t bh_bytes = bh_cells * 8u;
        uint8_t *bh_buf = (uint8_t *)malloc(bh_bytes);
        if (!bh_buf) { fclose(fp); return CVP_ERR_OOM; }
        uint8_t *bp = bh_buf;
        for (uint16_t y = BH_Y0; y < (uint16_t)(BH_Y0 + BH_H); y++) {
            for (uint16_t x = BH_X0; x < (uint16_t)(BH_X0 + BH_W); x++) {
                const Cell *c = &ctx->cells[(uint32_t)y * CANVAS_W + x];
                *bp++ = (uint8_t)(c->A);     *bp++ = (uint8_t)(c->A>>8);
                *bp++ = (uint8_t)(c->A>>16); *bp++ = (uint8_t)(c->A>>24);
                *bp++ = c->B; *bp++ = c->G; *bp++ = c->R; *bp++ = c->pad;
            }
        }
        rc = write_section(fp, CVP_SEC_BH_STATE, CVP_FLAG_OPTIONAL,
                            bh_buf, bh_bytes);
        free(bh_buf);
        if (rc != CVP_OK) { fclose(fp); return rc; }
        section_count++;
    }

    /* ---- fill in real header ---- */
    long data_end = ftell(fp);
    fseek(fp, 0, SEEK_SET);
    memset(hdr_buf, 0, sizeof(hdr_buf));
    uint8_t *h = hdr_buf;
    h[0]='C'; h[1]='V'; h[2]='P'; h[3]='1';   /* magic */
    /* version */
    h[4]=(uint8_t)CVP_VERSION;      h[5]=(uint8_t)(CVP_VERSION>>8);
    h[6]=(uint8_t)(CVP_VERSION>>16);h[7]=(uint8_t)(CVP_VERSION>>24);
    /* endian check */
    h[8]=0x78; h[9]=0x56; h[10]=0x34; h[11]=0x12;
    /* canvas_w */
    h[12]=(uint8_t)CANVAS_W;  h[13]=(uint8_t)(CANVAS_W>>8);  h[14]=0; h[15]=0;
    /* canvas_h */
    h[16]=(uint8_t)CANVAS_H;  h[17]=(uint8_t)(CANVAS_H>>8);  h[18]=0; h[19]=0;
    /* section_count */
    h[20]=(uint8_t)section_count; h[21]=(uint8_t)(section_count>>8);
    h[22]=(uint8_t)(section_count>>16); h[23]=(uint8_t)(section_count>>24);
    /* reserved_lo */
    uint32_t rlo=FS_RESERVED_LO, rhi=FS_RESERVED_HI;
    h[24]=(uint8_t)rlo; h[25]=(uint8_t)(rlo>>8); h[26]=(uint8_t)(rlo>>16); h[27]=(uint8_t)(rlo>>24);
    /* reserved_hi */
    h[28]=(uint8_t)rhi; h[29]=(uint8_t)(rhi>>8); h[30]=(uint8_t)(rhi>>16); h[31]=(uint8_t)(rhi>>24);
    /* header_crc32 over bytes 0..31 */
    uint32_t hcrc = cvp_crc32(h, 32);
    h[32]=(uint8_t)hcrc; h[33]=(uint8_t)(hcrc>>8);
    h[34]=(uint8_t)(hcrc>>16); h[35]=(uint8_t)(hcrc>>24);

    if (fwrite(hdr_buf, 1, CVP_HEADER_SIZE, fp) != CVP_HEADER_SIZE) {
        fclose(fp); return CVP_ERR_IO;
    }
    fseek(fp, data_end, SEEK_SET);
    fclose(fp);
    (void)data_end;
    return CVP_OK;
}

/* =====================================================
 * VALIDATE
 * ===================================================== */
CvpResult cvp_validate(const char *path) {
    FILE *fp = fopen(path, "rb");
    if (!fp) return CVP_ERR_IO;

    uint8_t hdr[CVP_HEADER_SIZE];
    if (fread(hdr, 1, CVP_HEADER_SIZE, fp) != CVP_HEADER_SIZE) {
        fclose(fp); return CVP_ERR_IO;
    }
    fclose(fp);

    if (hdr[0]!='C'||hdr[1]!='V'||hdr[2]!='P'||hdr[3]!='1')
        return CVP_ERR_MAGIC;

    uint32_t ver = (uint32_t)hdr[4]|(uint32_t)hdr[5]<<8|
                   (uint32_t)hdr[6]<<16|(uint32_t)hdr[7]<<24;
    if ((ver >> 16) != 0x0001) return CVP_ERR_VERSION;

    uint32_t stored_crc = (uint32_t)hdr[32]|(uint32_t)hdr[33]<<8|
                          (uint32_t)hdr[34]<<16|(uint32_t)hdr[35]<<24;
    uint32_t calc_crc = cvp_crc32(hdr, 32);
    if (stored_crc != calc_crc) return CVP_ERR_CRC;

    return CVP_OK;
}

/* =====================================================
 * LOAD
 * ===================================================== */
CvpResult cvp_load(const char *path, EngineContext *ctx) {
    if (!path || !ctx || !ctx->cells) return CVP_ERR_IO;

    FILE *fp = fopen(path, "rb");
    if (!fp) return CVP_ERR_IO;

    /* validate header */
    uint8_t hdr[CVP_HEADER_SIZE];
    if (fread(hdr, 1, CVP_HEADER_SIZE, fp) != CVP_HEADER_SIZE) {
        fclose(fp); return CVP_ERR_IO;
    }
    if (hdr[0]!='C'||hdr[1]!='V'||hdr[2]!='P'||hdr[3]!='1') {
        fclose(fp); return CVP_ERR_MAGIC;
    }
    uint32_t ver = (uint32_t)hdr[4]|(uint32_t)hdr[5]<<8|
                   (uint32_t)hdr[6]<<16|(uint32_t)hdr[7]<<24;
    if ((ver >> 16) != 0x0001) { fclose(fp); return CVP_ERR_VERSION; }

    uint32_t stored_hcrc = (uint32_t)hdr[32]|(uint32_t)hdr[33]<<8|
                           (uint32_t)hdr[34]<<16|(uint32_t)hdr[35]<<24;
    if (cvp_crc32(hdr, 32) != stored_hcrc) { fclose(fp); return CVP_ERR_CRC; }

    uint32_t cw = (uint32_t)hdr[12]|(uint32_t)hdr[13]<<8;
    uint32_t ch = (uint32_t)hdr[16]|(uint32_t)hdr[17]<<8;
    if (cw != CANVAS_W || ch != CANVAS_H) { fclose(fp); return CVP_ERR_SIZE; }

    uint32_t section_count = (uint32_t)hdr[20]|(uint32_t)hdr[21]<<8|
                             (uint32_t)hdr[22]<<16|(uint32_t)hdr[23]<<24;
    bool found_canvas = false;

    for (uint32_t s = 0; s < section_count; s++) {
        uint32_t type, flags, length, crc;
        if (read_u32le(fp, &type)   < 0 ||
            read_u32le(fp, &flags)  < 0 ||
            read_u32le(fp, &length) < 0 ||
            read_u32le(fp, &crc)    < 0) {
            fclose(fp); return CVP_ERR_IO;
        }
        uint8_t *payload = NULL;
        if (length > 0) {
            payload = (uint8_t *)malloc(length);
            if (!payload) { fclose(fp); return CVP_ERR_OOM; }
            if (fread(payload, 1, length, fp) != length) {
                free(payload); fclose(fp); return CVP_ERR_IO;
            }
            if (cvp_crc32(payload, length) != crc) {
                free(payload); fclose(fp); return CVP_ERR_CRC;
            }
        }

        if (type == CVP_SEC_CANVAS_BASE) {
            uint32_t cell_count = (uint32_t)CANVAS_W * CANVAS_H;
            if (length < cell_count * 8u) { free(payload); fclose(fp); return CVP_ERR_SIZE; }
            const uint8_t *d = payload;
            for (uint32_t i = 0; i < cell_count; i++, d += 8) {
                Cell *c = &ctx->cells[i];
                c->A = (uint32_t)d[0]|((uint32_t)d[1]<<8)|
                       ((uint32_t)d[2]<<16)|((uint32_t)d[3]<<24);
                c->B = d[4]; c->G = d[5]; c->R = d[6]; c->pad = d[7];
            }
            found_canvas = true;
        }
        else if (type == CVP_SEC_GATE_BITMAP && ctx->gates && length >= 512) {
            for (uint32_t g = 0; g < TILE_COUNT; g++) {
                bool open = (payload[g/8] >> (g%8)) & 1;
                ctx->gates[g] = open ? GATE_OPEN : GATE_CLOSE;
                if (ctx->active_open) ctx->active_open[g] = open ? 1 : 0;
            }
        }
        else if (type == CVP_SEC_BH_STATE && length >= 8) {
            /* restore BH cells */
            uint32_t bh_cells = (uint32_t)BH_W * (uint32_t)BH_H;
            const uint8_t *bp = payload;
            for (uint16_t y = BH_Y0; y < (uint16_t)(BH_Y0+BH_H) && bh_cells > 0; y++) {
                for (uint16_t x = BH_X0; x < (uint16_t)(BH_X0+BH_W) && bh_cells > 0; x++, bh_cells--, bp += 8) {
                    Cell *c = &ctx->cells[(uint32_t)y * CANVAS_W + x];
                    c->A = (uint32_t)bp[0]|((uint32_t)bp[1]<<8)|
                           ((uint32_t)bp[2]<<16)|((uint32_t)bp[3]<<24);
                    c->B = bp[4]; c->G = bp[5]; c->R = bp[6]; c->pad = bp[7];
                }
            }
        }
        /* WH_LANE and RULETABLE: skip for now (Phase 4 replay handles WH) */

        if (payload) free(payload);
    }

    fclose(fp);
    return found_canvas ? CVP_OK : CVP_ERR_SECTION;
}

/* =====================================================
 * REPLAY — re-execute WH records from file into ctx
 * ===================================================== */
CvpResult cvp_replay(const char *path, EngineContext *ctx,
                     const CvpReplayOpts *opts) {
    if (!path || !ctx) return CVP_ERR_IO;

    FILE *fp = fopen(path, "rb");
    if (!fp) return CVP_ERR_IO;

    uint8_t hdr[CVP_HEADER_SIZE];
    if (fread(hdr, 1, CVP_HEADER_SIZE, fp) != CVP_HEADER_SIZE) {
        fclose(fp); return CVP_ERR_IO;
    }
    if (hdr[0]!='C'||hdr[1]!='V'||hdr[2]!='P'||hdr[3]!='1') {
        fclose(fp); return CVP_ERR_MAGIC;
    }
    uint32_t section_count = (uint32_t)hdr[20]|(uint32_t)hdr[21]<<8|
                             (uint32_t)hdr[22]<<16|(uint32_t)hdr[23]<<24;

    CvpResult result = CVP_ERR_SECTION;  /* no WH_LANE found by default */

    for (uint32_t s = 0; s < section_count; s++) {
        uint32_t type, flags, length, crc;
        if (read_u32le(fp, &type)  < 0 || read_u32le(fp, &flags) < 0 ||
            read_u32le(fp, &length)< 0 || read_u32le(fp, &crc)   < 0) {
            fclose(fp); return CVP_ERR_IO;
        }
        if (type != CVP_SEC_WH_LANE) {
            fseek(fp, (long)length, SEEK_CUR);
            continue;
        }
        uint8_t *wh_payload = (uint8_t *)malloc(length);
        if (!wh_payload) { fclose(fp); return CVP_ERR_OOM; }
        if (fread(wh_payload, 1, length, fp) != length) {
            free(wh_payload); fclose(fp); return CVP_ERR_IO;
        }
        if (cvp_crc32(wh_payload, length) != crc) {
            free(wh_payload); fclose(fp); return CVP_ERR_CRC;
        }

        /* parse CvpWhLaneHdr */
        if (length < 20) { free(wh_payload); continue; }
        const uint8_t *p = wh_payload;
        uint64_t tick_first = 0, tick_last = 0;
        for (int i=0;i<8;i++) { tick_first |= ((uint64_t)p[i])<<(8*i); } p+=8;
        for (int i=0;i<8;i++) { tick_last  |= ((uint64_t)p[i])<<(8*i); } p+=8;
        uint32_t rec_count = (uint32_t)p[0]|(uint32_t)p[1]<<8|
                             (uint32_t)p[2]<<16|(uint32_t)p[3]<<24; p+=4;

        uint64_t tf = opts ? opts->tick_from : 0;
        uint64_t tl = opts ? opts->tick_to   : (uint64_t)-1;
        bool dry    = opts ? opts->dry_run    : false;

        for (uint32_t i = 0; i < rec_count && (p + 16) <= (wh_payload + length); i++, p += 16) {
            WhRecord r;
            r.tick_or_event = (uint32_t)p[0]|(uint32_t)p[1]<<8|
                              (uint32_t)p[2]<<16|(uint32_t)p[3]<<24;
            r.opcode_index  = p[4];
            r.flags         = p[5];
            r.param0        = p[6];
            r.target_addr   = (uint32_t)p[8]|(uint32_t)p[9]<<8|
                              (uint32_t)p[10]<<16|(uint32_t)p[11]<<24;
            r.target_kind   = p[12];
            r.arg_state     = p[13];
            r.param1        = p[14];

            uint64_t t = (uint64_t)r.tick_or_event;
            if (t < tf || t > tl) continue;
            if (!dry) wh_exec_record(ctx, &r);
        }
        (void)tick_first; (void)tick_last;
        free(wh_payload);
        result = CVP_OK;
        break;
    }

    fclose(fp);
    return result;
}
